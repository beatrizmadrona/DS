﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1, num2, soma;
            num1 = int.Parse(textBox1.Text);
            num2 = int.Parse(textBox2.Text); // outra possibilidade é Convert.ToInt32

            //outras conversões
            //double V = double.Parse(textbox1.text); //Conversão de string para double
            //ou double V = Convert.ToDouble(texbox1.text);
            //bool R = bool.Parse(textbox1.text); // Conversão de string para Boolean
            //ou bool R = Convert.ToBoolean(textbox1.text);
            // char L = char.Parse(textbox1.text); // String para char
            // char L = Convert.ToChar(textbox1.text);

            //OPERADORES ARITMÉTICOS
            // + Adição
            // - Subtração
            // * Multiplicação
            // / Divisão
            // % Resto da Divisão

            //OPERADORES RELACIONAIS
            //>Maior do que
            //>= Maior ou igual a
            //== Igual a
            //! Diferente de
            soma = num1 + num2;
            label4.Text = soma.ToString();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            label4.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
