﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1, num2, soma;
            num1 = int.Parse(textBox1.Text);
            num2 = int.Parse(textBox2.Text);

            soma = num1 + num2;
            label4.Text = soma.ToString();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
